# Opera

```
index.html            الصفحة الرئيسية (الملف الوحيد في الجذر مع package.json و vercel.json)
pages/                باقي الصفحات: about, gallery, services, tools, faq, login, register, forgot, 404
assets/
  css/styles.css      التنسيق
  js/                 الناتج بعد الترجمة من TypeScript (يُستخدم في الصفحات، لا تعدّله يدوياً)
  icons/              الأيقونات وصورة المشاركة
  manifest.webmanifest, sw.js   تطبيق PWA والعمل بدون إنترنت
src/                  الكود المصدري (TypeScript)
  main.ts             نقطة البداية
  core/               utils, i18n (كشف اللغة), lang-en (الترجمة), lock (قفل الزوم والتحريك)
  components/         gallery, ui, features, login, auth (نماذج الدخول والتسجيل واستعادة كلمة السر)
  effects/            particles, shapes, robot (مرشد الموقع: روبوت ثلاثي الأبعاد بقائمة اختصارات)
config/tsconfig.json  إعدادات TypeScript
docs/                 هذا الملف
```

بعد تعديل أي ملف في `src` شغّل: `npm i` ثم `npm run build`.
للتجربة المحلية: `npm start` (الوحدات تحتاج خادماً، لا تعمل بفتح الملف مباشرة).

## اللغة
يكشف الموقع لغة الجهاز: عربي → عربي (RTL)، غير ذلك → إنجليزي (LTR). الزر أعلى الصفحة يبدّل يدوياً ويحفظ الاختيار.
النصوص العربية في HTML هي الأصل، وترجمتها الإنجليزية في `src/core/lang-en.ts` (المفتاح هو النص العربي كما هو في الصفحة).
عند إضافة نص جديد في الصفحة أضف ترجمته هناك، وإلا يبقى عربياً في النسخة الإنجليزية.

## ملاحظات النشر
`vercel.json` يضبط صفحة 404 المخصصة وترويسة `Service-Worker-Allowed` لأن `sw.js` داخل `assets/`.
على استضافة غير Vercel قد لا يعمل وضع "بدون إنترنت" (باقي الموقع يعمل عادي).

## الحسابات (مربوطة بالقاعدة)
- `/api/auth/register` تسجيل → رسالة تأكيد على البريد → `/api/auth/verify` يفعّل الحساب.
- `/api/auth/forgot` يرسل رابط استعادة → `pages/forgot.html?token=...` لتعيين كلمة جديدة → `/api/auth/reset`.
- `/api/auth/login`, `/api/auth/me`, `/api/auth/logout`.
- البريد: ضع `RESEND_API_KEY` و `MAIL_FROM` (و `PUBLIC_URL` عند النشر). في وضع اختبار Resend، الإرسال محدود بعنوان حسابك؛ لإرسال الأكواد إلى المستخدمين تحقّق من نطاق المرسل في Resend واضبط `MAIL_FROM` على عنوان منه. بدون مفتاح API تُطبع الرسائل في الطرفية.
- التسجيل مغلق ما دام `security.single_owner = true` أو `auth.registration_open = false` في `site_settings`.

## وضع المطور (موقوف)
حساب الطوارئ للمطور (D11) معطّل افتراضياً: الدخول بإيميله يُرفض كأي بريد مجهول. لتفعيله مؤقتاً شغّل الخادم بـ `OPERA_DEV_MODE=1`، وأوقفه بإزالة المتغير.

## الدخول عبر Google وGitHub والبصمة
الثلاثة مبنية ومختبرة (`npm run db:test`). يربط Google أو GitHub تلقائياً حساب الموقع النشط إذا طابقه البريد المؤكَّد من المزوّد. يمكن إنشاء حساب جديد عبرهما عندما يكون `auth.registration_open = true` و`security.single_owner` غير مفعّل. يجب أن يكون البريد مؤكداً لدى المزوّد.

**Google و GitHub** (تحتاج مفاتيح منك، وبدونها يظهر للزائر «لم يُفعَّل بعد»):
1. Google: console.cloud.google.com ← APIs & Services ← Credentials ← OAuth client ID (Web). GitHub: Settings ← Developer settings ← OAuth Apps.
2. عنوان الرجوع (Redirect / Callback URL) المسجّل لدى Google: `{PUBLIC_URL}/auth/google/callback`، ولدى GitHub: `{PUBLIC_URL}/api/auth/oauth/github/callback`.
   استخدم عنوان HTTPS الظاهر لمشروع Replit بوصفه `PUBLIC_URL`. للاختبار المحلي استخدم `http://localhost:3000/auth/google/callback` و`http://localhost:3000/api/auth/oauth/github/callback`.
3. شغّل الخادم بالمتغيرات: `GOOGLE_CLIENT_ID` `GOOGLE_CLIENT_SECRET` `GITHUB_CLIENT_ID` `GITHUB_CLIENT_SECRET` (و`PUBLIC_URL` عند النشر).

**البصمة (WebAuthn):** لا تحتاج مفاتيح. سجّل الدخول بالبريد ثم افتح صفحة الدخول واضغط «إضافة بصمة لهذا الجهاز». بعدها زر «الدخول ببصمة الهاتف» يعمل. تعمل على `https` أو `localhost` فقط (شرط المتصفحات).
