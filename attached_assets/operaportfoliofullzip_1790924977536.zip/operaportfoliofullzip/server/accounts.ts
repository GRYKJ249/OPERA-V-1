import type { DatabaseSync } from 'node:sqlite';
import { createHash, randomBytes, randomInt, timingSafeEqual } from 'node:crypto';
import { hashPassword } from './password.ts';
import { sendMail } from './mailer.ts';
import { resetCodeEmail, verifyCodeEmail } from './mail-templates.ts';

const sha = (s: string) => createHash('sha256').update(s).digest('hex');
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const newToken = () => randomBytes(32).toString('base64url');

/** حد بسيط للطلبات: max مرات لكل مفتاح خلال ساعة */
export function limited(db: DatabaseSync, key: string, max: number): boolean {
  const w = new Date().toISOString().slice(0, 13); // نافذة ساعة
  db.prepare('INSERT INTO rate_limits (key, window_start, hits) VALUES (?,?,1) ON CONFLICT(key, window_start) DO UPDATE SET hits = hits + 1').run(key, w);
  const r = db.prepare('SELECT hits FROM rate_limits WHERE key = ? AND window_start = ?').get(key, w) as any;
  return Number(r?.hits ?? 0) > max;
}

/** رمز تأكيد الحساب: 6 أرقام صالح 15 دقيقة، 5 محاولات خاطئة كحد أقصى (نفس نظام استعادة كلمة السر) */
const VERIFY_MINUTES = 15, VERIFY_MAX_ATTEMPTS = 5;
const verifyHash = (userId: number, code: string) => sha(`signup:${userId}:${code}`);

async function sendVerifyCode(db: DatabaseSync, userId: number, email: string) {
  const code = String(randomInt(0, 1_000_000)).padStart(6, '0');
  db.exec('BEGIN');
  try {
    db.prepare("UPDATE email_verifications SET used_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE user_id = ? AND used_at IS NULL").run(userId);
    db.prepare(`INSERT INTO email_verifications (user_id, token_hash, expires_at) VALUES (?,?,strftime('%Y-%m-%dT%H:%M:%fZ','now','+${VERIFY_MINUTES} minutes'))`).run(userId, verifyHash(userId, code));
    db.exec('COMMIT');
  } catch (e) { db.exec('ROLLBACK'); throw e; }
  const m = verifyCodeEmail(code, VERIFY_MINUTES);
  await sendMail(email, m.subject, m.text, m.html);
}

/** مفتاح موحّد لبريد Gmail: Gmail يتجاهل النقاط وما بعد + وgooglemail = gmail، فكلها صندوق واحد */
export function mailboxKey(email: string): string {
  const [local, domain] = email.toLowerCase().split('@');
  if (domain === 'gmail.com' || domain === 'googlemail.com') return `${local.split('+')[0].replace(/\./g, '')}@gmail.com`;
  return email.toLowerCase();
}

/** هل البريد (أو صندوقه نفسه في Gmail) مسجّل؟ يرجع الصف الموجود */
function findExisting(db: DatabaseSync, email: string): { id: number; status: string } | undefined {
  const exact = db.prepare('SELECT id, status FROM users WHERE email = ?').get(email) as any;
  if (exact) return { id: Number(exact.id), status: exact.status };
  const key = mailboxKey(email);
  if (!key.endsWith('@gmail.com')) return undefined;
  const rows = db.prepare("SELECT id, status, email FROM users WHERE (email LIKE '%@gmail.com' OR email LIKE '%@googlemail.com') AND lower(substr(email,1,1)) = ?").all(email[0].toLowerCase()) as any[];
  const hit = rows.find(r => mailboxKey(String(r.email)) === key);
  return hit ? { id: Number(hit.id), status: hit.status } : undefined;
}

export type RegisterResult = { ok: true; resumed?: boolean } | { ok: false; code: 'bad_request' | 'weak_password' | 'rate_limited' | 'closed' | 'email_exists' };

/** إنشاء حساب جديد بحالة pending حتى يُدخل رمز التأكيد. بريد مسجّل مسبقاً = رفض صريح (email_exists). */
export async function register(db: DatabaseSync, o: { name: string; email: string; password: string; terms: boolean; ip?: string; origin: string }): Promise<RegisterResult> {
  const name = String(o.name ?? '').trim().slice(0, 80), email = String(o.email ?? '').trim().toLowerCase().slice(0, 254);
  const password = String(o.password ?? '');
  if (!name || !EMAIL.test(email) || !o.terms) return { ok: false, code: 'bad_request' };
  if (password.length < 8 || password.length > 1024) return { ok: false, code: 'weak_password' };
  const setting = (k: string) => (db.prepare('SELECT value FROM site_settings WHERE key = ?').get(k) as any)?.value;
  if (setting('auth.registration_open') !== 'true' || setting('security.single_owner') === 'true') return { ok: false, code: 'closed' };
  if (limited(db, `register:${o.ip ?? '-'}`, 10)) return { ok: false, code: 'rate_limited' };

  // فحص القاعدة قبل أي إنشاء: مسجّل ومفعّل = رفض. مسجّل ولم يؤكد = نرسل رمزاً جديداً دون المساس بكلمة سره الأصلية.
  const existing = findExisting(db, email);
  if (existing) {
    if (existing.status !== 'pending') return { ok: false, code: 'email_exists' };
    if (limited(db, `signup-code:${email}`, 5)) return { ok: false, code: 'rate_limited' };
    await sendVerifyCode(db, existing.id, email);
    return { ok: true, resumed: true };
  }
  let id: number;
  try {
    const r = db.prepare(`INSERT INTO users (email, display_name, password_hash, status, terms_accepted_at, password_changed_at)
      VALUES (?,?,?,'pending',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now'))`).run(email, name, hashPassword(password));
    id = Number(r.lastInsertRowid);
  } catch (e) {
    // سباق نادر: طلبان بنفس البريد معاً. قيد UNIQUE في القاعدة يرفض الثاني.
    if (/UNIQUE/i.test((e as Error).message)) return { ok: false, code: 'email_exists' };
    throw e;
  }
  db.prepare("INSERT OR IGNORE INTO user_roles (user_id, role_id) SELECT ?, id FROM roles WHERE name = 'user'").run(id);
  await sendVerifyCode(db, id, email);
  return { ok: true };
}

/** إعادة إرسال رمز التأكيد لحساب لم يؤكَّد بعد. الرد دائماً نجاح. */
export async function resendVerifyCode(db: DatabaseSync, o: { email: string; ip?: string }): Promise<{ ok: boolean; code?: 'rate_limited' }> {
  const email = String(o.email ?? '').trim().toLowerCase().slice(0, 254);
  if (!EMAIL.test(email)) return { ok: true };
  if (limited(db, `signup-code-ip:${o.ip ?? '-'}`, 10) || limited(db, `signup-code:${email}`, 5)) return { ok: false, code: 'rate_limited' };
  const u = db.prepare("SELECT id FROM users WHERE email = ? AND status = 'pending'").get(email) as any;
  if (u) await sendVerifyCode(db, Number(u.id), email);
  return { ok: true };
}

/** تأكيد الحساب بالرمز المرسل للبريد: يفعّل الحساب */
export function verifySignupCode(db: DatabaseSync, o: { email: string; code: string }): 'ok' | 'invalid' {
  const email = String(o.email ?? '').trim().toLowerCase().slice(0, 254), code = String(o.code ?? '').trim();
  if (!EMAIL.test(email) || !/^\d{6}$/.test(code)) return 'invalid';
  const u = db.prepare("SELECT id FROM users WHERE email = ? AND status = 'pending'").get(email) as any;
  if (!u) return 'invalid';
  const v = db.prepare("SELECT id, token_hash FROM email_verifications WHERE user_id = ? AND used_at IS NULL AND attempts < ? AND expires_at > strftime('%Y-%m-%dT%H:%M:%fZ','now') ORDER BY id DESC LIMIT 1").get(u.id, VERIFY_MAX_ATTEMPTS) as any;
  if (!v) return 'invalid';
  const a = Buffer.from(v.token_hash, 'hex'), b = Buffer.from(verifyHash(Number(u.id), code), 'hex');
  if (a.length !== b.length || !timingSafeEqual(a, b)) {
    db.prepare('UPDATE email_verifications SET attempts = attempts + 1 WHERE id = ?').run(v.id);
    return 'invalid';
  }
  db.exec('BEGIN');
  try {
    db.prepare("UPDATE email_verifications SET used_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?").run(v.id);
    db.prepare("UPDATE users SET status = 'active', email_verified_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ? AND status = 'pending'").run(u.id);
    db.exec('COMMIT');
  } catch (e) { db.exec('ROLLBACK'); throw e; }
  return 'ok';
}

/** تأكيد البريد من الرابط (للرسائل القديمة فقط؛ الحسابات الجديدة تُؤكَّد بالرمز). */
export function verifyEmail(db: DatabaseSync, token: string): boolean {
  if (!token || token.length > 100) return false;
  const v = db.prepare("SELECT id, user_id FROM email_verifications WHERE token_hash = ? AND used_at IS NULL AND expires_at > strftime('%Y-%m-%dT%H:%M:%fZ','now')").get(sha(token)) as any;
  if (!v) return false;
  db.exec('BEGIN');
  try {
    db.prepare("UPDATE email_verifications SET used_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?").run(v.id);
    db.prepare("UPDATE users SET status = 'active', email_verified_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ? AND status = 'pending'").run(v.user_id);
    db.exec('COMMIT');
  } catch (e) { db.exec('ROLLBACK'); throw e; }
  return true;
}

/** رمز الاستعادة: 6 أرقام صالح 15 دقيقة، 5 محاولات خاطئة كحد أقصى */
const RESET_MINUTES = 15, RESET_MAX_ATTEMPTS = 5;
const codeHash = (userId: number, code: string) => sha(`${userId}:${code}`);

/** طلب استعادة كلمة السر. الرد دائماً نجاح حتى لا نكشف وجود البريد. */
export async function requestReset(db: DatabaseSync, o: { email: string; ip?: string; origin?: string }): Promise<{ ok: boolean; code?: 'rate_limited' }> {
  const email = String(o.email ?? '').trim().toLowerCase().slice(0, 254);
  if (!EMAIL.test(email)) return { ok: true };
  if (limited(db, `reset:${o.ip ?? '-'}`, 5) || limited(db, `reset:${email}`, 3)) return { ok: false, code: 'rate_limited' };
  const u = db.prepare("SELECT id FROM users WHERE email = ? AND status = 'active'").get(email) as any;
  if (!u) return { ok: true };
  const code = String(randomInt(0, 1_000_000)).padStart(6, '0');
  db.exec('BEGIN');
  try {
    db.prepare("UPDATE password_resets SET used_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE user_id = ? AND used_at IS NULL").run(u.id);
    db.prepare(`INSERT INTO password_resets (user_id, token_hash, expires_at, ip) VALUES (?,?,strftime('%Y-%m-%dT%H:%M:%fZ','now','+${RESET_MINUTES} minutes'),?)`).run(u.id, codeHash(u.id, code), o.ip ?? null);
    db.exec('COMMIT');
  } catch (e) { db.exec('ROLLBACK'); throw e; }
  const m = resetCodeEmail(code, RESET_MINUTES);
  await sendMail(email, m.subject, m.text, m.html);
  return { ok: true };
}

/** تعيين كلمة سر جديدة بالرمز المرسل للبريد. يلغي كل الجلسات القديمة. */
export function resetPassword(db: DatabaseSync, o: { email: string; code: string; password: string }): 'ok' | 'invalid' | 'weak_password' {
  const email = String(o.email ?? '').trim().toLowerCase().slice(0, 254);
  const code = String(o.code ?? '').trim();
  const password = String(o.password ?? '');
  if (!EMAIL.test(email) || !/^\d{6}$/.test(code)) return 'invalid';
  if (password.length < 8 || password.length > 1024) return 'weak_password';
  const u = db.prepare("SELECT id FROM users WHERE email = ? AND status = 'active'").get(email) as any;
  if (!u) return 'invalid';
  const r = db.prepare("SELECT id, token_hash FROM password_resets WHERE user_id = ? AND used_at IS NULL AND attempts < ? AND expires_at > strftime('%Y-%m-%dT%H:%M:%fZ','now') ORDER BY id DESC LIMIT 1").get(u.id, RESET_MAX_ATTEMPTS) as any;
  if (!r) return 'invalid';
  const a = Buffer.from(r.token_hash, 'hex'), b = Buffer.from(codeHash(u.id, code), 'hex');
  if (a.length !== b.length || !timingSafeEqual(a, b)) {
    db.prepare("UPDATE password_resets SET attempts = attempts + 1 WHERE id = ?").run(r.id);
    return 'invalid';
  }
  db.exec('BEGIN');
  try {
    db.prepare("UPDATE password_resets SET used_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?").run(r.id);
    db.prepare("UPDATE users SET password_hash = ?, password_changed_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), must_change_password = 0, failed_login_count = 0, locked_until = NULL WHERE id = ?").run(hashPassword(password), u.id);
    db.prepare("UPDATE sessions SET revoked_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE user_id = ? AND revoked_at IS NULL").run(u.id);
    db.exec('COMMIT');
  } catch (e) { db.exec('ROLLBACK'); throw e; }
  return 'ok';
}
